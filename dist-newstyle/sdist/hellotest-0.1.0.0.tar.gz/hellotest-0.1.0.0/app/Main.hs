module Main where

import Graphics.UI.GLUT

main :: IO ()
main = do
  (_progName, _args) <- getArgsAndInitialize
  initialDisplayMode $= [DoubleBuffered, RGBMode]
  initialWindowSize $= Size 200 200
  initialWindowPosition $= Position 100 100
  _window <- createWindow "Hello World"
  displayCallback $= display
  mainLoop

display :: DisplayCallback
display = do
  clear [ColorBuffer]
  renderPrimitive Triangles $ do
    vertex $ Vertex3 0.0 1.0 (0.0 :: GLfloat)
    vertex $ Vertex3 1.0 (-1.0) (0.0 :: GLfloat)
    vertex $ Vertex3 (-1.0) (-1.0) (0.0 :: GLfloat)
  flush
